package com.app.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import java.util.Date;

@Data
public class Product {
    private String productId;
    private String productName;
    private String unitOfMeasure;
    private String status;

    public Product(String productId, String productName, String unitOfMeasure) {
        this.productId = productId;
        this.productName = productName;
        this.unitOfMeasure = unitOfMeasure;
    }
}
