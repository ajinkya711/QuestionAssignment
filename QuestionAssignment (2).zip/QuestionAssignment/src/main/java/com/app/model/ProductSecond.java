package com.app.model;

import lombok.Data;

@Data
public class ProductSecond {
    private String productId;
    private String productName;
    private String unitOfMeasure;
    private String launchDate;
}
